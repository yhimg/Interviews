Please document here:
* Classes you have implemented or modified, including test classes
* Any assumptions that affected your design
* Any shortcomings of your implementation
* An explanation of your definition of fairness execution