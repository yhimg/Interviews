package com.workday.java;

/**
 *
 * Your code goes here
 *
 */

public class JobRunnerImpl implements JobRunner {

    @Override
    public void run(JobQueue jobQueue) {

    }

    @Override
    public void shutdown() {

    }
}
